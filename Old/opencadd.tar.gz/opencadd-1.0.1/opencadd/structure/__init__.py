"""
opencadd.structure module
"""
